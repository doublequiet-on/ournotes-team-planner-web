"""Selected cards' own parameters and Snap support rates, from pinned bdon data.

Only actual development values are accepted: player training / awakening /
limit-break counts are 0..4 and map to raw rows 1..5. No maximum development
or zero bonus is substituted for missing input. This module does not calculate
team power, event effects, character ranks, links, memories, or live scores.

Member terms reproduce the two float32 operation orders documented in bdon's
cards/growth.ts. Snap base support rates use its levelParameters calculation;
the result is fixed-point with 10000 = 100%. The real screenshots supplied on
2026-10-01 independently match all five member triples and five Snap triples.
"""

from __future__ import annotations

import hashlib
import json
import math
from pathlib import Path
import struct


TABLE_NAMES = (
    "MasterMemberCard", "MasterMemberCardLevel", "MasterMemberCardAwake",
    "MasterMemberCardRank", "MasterMemberCardLevelLimit", "MasterSupportCard",
    "MasterSupportCardLevel", "MasterSupportCardRank", "MasterText",
)
FORMULA_SOURCES = (
    "source_reference/src/lib/cards/growth.ts",
    "source_reference/src/lib/support-cards/growth.ts",
)
REQUIRED_PATHS = tuple(f"raw/{name}.json" for name in TABLE_NAMES) + FORMULA_SOURCES
PARAMETERS = ("performance", "technic", "visual")
RATE_SCALE = 10000


def _integer(value: object, label: str, minimum: int = 0,
             maximum: int | None = None) -> int:
    if type(value) is not int:
        raise ValueError(f"{label} must be an integer; booleans are not accepted")
    if value < minimum or (maximum is not None and value > maximum):
        raise ValueError(f"{label} is outside the supported range")
    return value


def _required_integer(entry: dict, key: str, label: str, minimum: int = 0,
                      maximum: int | None = None) -> int:
    if key not in entry:
        raise ValueError(f"{label} requires its actual {key}; no default is assumed")
    return _integer(entry[key], f"{label}.{key}", minimum, maximum)


def _float32(value: int | float) -> float:
    return struct.unpack("<f", struct.pack("<f", value))[0]


def _scale_product_then_ratio(maximum: int, rate: int) -> int:
    # Math.floor(Math.fround(Math.fround(rate * max) / 10000)).
    return math.floor(_float32(_float32(rate * maximum) / RATE_SCALE))


def _scale_ratio_then_product(maximum: int, rate: int) -> int:
    # Training uses the other operation order in the client reference.
    return math.floor(_float32(_float32(rate / RATE_SCALE) * _float32(maximum)))


def _snapshot(snapshot_dir: Path) -> tuple[dict, dict[str, list[dict]]]:
    manifest = json.loads((snapshot_dir / "source_manifest.json").read_text(encoding="utf-8"))
    entries = {entry["local_path"]: entry for entry in manifest["files"]}
    tables = {}
    for relative in REQUIRED_PATHS:
        entry = entries.get(relative)
        if entry is None:
            raise ValueError(f"Snapshot manifest does not contain {relative}")
        payload = (snapshot_dir / relative).read_bytes()
        if hashlib.sha256(payload).hexdigest() != entry["sha256"]:
            raise ValueError(f"Snapshot checksum does not match: {relative}")
        if relative.startswith("raw/"):
            table = json.loads(payload)
            if not isinstance(table, dict) or not isinstance(table.get("_allData"), list):
                raise ValueError(f"Invalid table shape: {relative}")
            rows = table["_allData"]
            identifiers = set()
            for row in rows:
                if not isinstance(row, dict) or "_id" not in row:
                    raise ValueError(f"Invalid table row: {relative}")
                identifier = row["_id"]
                if type(identifier) not in (int, str) or identifier in identifiers:
                    raise ValueError(f"Invalid or duplicate table ID in {relative}")
                identifiers.add(identifier)
            tables[Path(relative).stem] = rows
    return manifest, tables


def _unique(rows: list[dict], label: str, **criteria: int) -> dict:
    matches = [row for row in rows if all(row.get(key) == value for key, value in criteria.items())]
    if len(matches) != 1:
        raise ValueError(f"{label}: expected one matching source row, got {len(matches)}")
    return matches[0]


def _inventory(profile: dict, kind: str) -> dict[int, dict]:
    if not isinstance(profile, dict) or not isinstance(profile.get("inventory"), dict):
        raise ValueError("profile.inventory must be an object")
    rows = profile["inventory"].get(kind)
    if not isinstance(rows, list):
        raise ValueError(f"profile.inventory.{kind} must be an array")
    indexed = {}
    for row in rows:
        if not isinstance(row, dict):
            raise ValueError(f"inventory.{kind} entries must be objects")
        identifier = _required_integer(row, "id", f"inventory.{kind}", minimum=1)
        if identifier in indexed:
            raise ValueError(f"Duplicate inventory {kind} ID {identifier}")
        indexed[identifier] = row
    return indexed


def _selection(ids: list[int], owned: dict[int, dict], kind: str) -> list[int]:
    if not isinstance(ids, list):
        raise ValueError(f"Selected {kind} IDs must be an explicit array")
    seen = set()
    for identifier in ids:
        _integer(identifier, f"selected {kind} ID", minimum=1)
        if identifier in seen:
            raise ValueError(f"Duplicate selected {kind} ID {identifier}")
        if identifier not in owned:
            raise ValueError(f"Selected {kind} ID {identifier} is not owned")
        seen.add(identifier)
    return ids


def _rates(row: dict, label: str) -> dict[str, int]:
    return {name: _required_integer(row, f"_{name}Rate", label) for name in PARAMETERS}


def _maxima(card: dict, label: str) -> dict[str, int]:
    return {name: _required_integer(card, f"_{name}PowerMax", label) for name in PARAMETERS}


def _label(card: dict, text: dict[str, str], title_key: str) -> dict[str, str]:
    return {"name": text[card["_nameTextID"]], "title": text[card[title_key]]}


def _member(tables: dict[str, list[dict]], text: dict[str, str], identifier: int,
            owned: dict) -> dict:
    label = f"member {identifier}"
    card = _unique(tables["MasterMemberCard"], label, _id=identifier)
    level = _required_integer(owned, "level", label, minimum=1)
    training = _required_integer(owned, "training_count", label, maximum=4)
    awakening = _required_integer(owned, "awakening_count", label, maximum=4)
    awake_row = _unique(tables["MasterMemberCardAwake"], f"{label} training",
                        _group=card["_memberCardAwakeGroup"], _awakeCount=training + 1)
    rank_row = _unique(tables["MasterMemberCardRank"], f"{label} awakening",
                       _group=card["_memberCardRankGroup"], _rank=awakening + 1)
    limit_row = _unique(tables["MasterMemberCardLevelLimit"], f"{label} level cap",
                        _rarity=card["_rarity"], _awakeCount=training + 1)
    cap = _required_integer(limit_row, "_limitLevel", label, minimum=1)
    if level > cap:
        raise ValueError(f"{label} level {level} exceeds its actual training cap {cap}")
    level_row = _unique(tables["MasterMemberCardLevel"], f"{label} level",
                        _group=card["_memberCardLevelGroup"], _level=level)
    maxima = _maxima(card, label)
    level_rates, awake_rates, rank_rates = (
        _rates(level_row, label), _rates(awake_row, label), _rates(rank_row, label),
    )
    terms = {}
    for name in PARAMETERS:
        maximum = maxima[name]
        terms[name] = {
            "level": _scale_product_then_ratio(maximum, level_rates[name]),
            "training": _scale_ratio_then_product(maximum, awake_rates[name]),
            "awakening": _scale_product_then_ratio(maximum, rank_rates[name]),
        }
    parameters = {name: sum(terms[name].values()) for name in PARAMETERS}
    parameters["total"] = sum(parameters.values())
    return {
        "id": identifier, **_label(card, text, "_subtitleTextID"),
        "level": level, "max_level": cap, "training_count": training,
        "awakening_count": awakening, "raw_awake_count": training + 1,
        "raw_rank": awakening + 1,
        "leader_skill_id": card["_leaderSkillID"],
        "leader_skill_level": _required_integer(rank_row, "_leaderSkillLevel", label, minimum=1),
        "parameters": parameters, "parameter_terms": terms,
        "source_row_ids": {"card": card["_id"], "level": level_row["_id"],
                           "training": awake_row["_id"], "awakening": rank_row["_id"],
                           "level_limit": limit_row["_id"]},
    }


def _snap(tables: dict[str, list[dict]], text: dict[str, str], identifier: int,
          owned: dict) -> dict:
    label = f"Snap {identifier}"
    card = _unique(tables["MasterSupportCard"], label, _id=identifier)
    level = _required_integer(owned, "level", label, minimum=1)
    limit_break = _required_integer(owned, "limit_break_count", label, maximum=4)
    rank_row = _unique(tables["MasterSupportCardRank"], f"{label} limit break",
                       _group=card["_supportCardRankGroup"], _rank=limit_break + 1)
    cap = _required_integer(rank_row, "_limitLevel", label, minimum=1)
    if level > cap:
        raise ValueError(f"{label} level {level} exceeds its actual limit-break cap {cap}")
    level_row = _unique(tables["MasterSupportCardLevel"], f"{label} level",
                        _group=card["_supportCardLevelGroup"], _level=level)
    maxima, rates = _maxima(card, label), _rates(level_row, label)
    values = {name: _scale_product_then_ratio(maxima[name], rates[name]) for name in PARAMETERS}
    return {
        "id": identifier, **_label(card, text, "_descriptionTextID"),
        "level": level, "max_level": cap, "limit_break_count": limit_break,
        "raw_rank": limit_break + 1,
        "support_skill_id": card["_supportSkillId01"],
        "support_skill_level": _required_integer(rank_row, "_supportSkill01Level", label, minimum=1),
        "support_skill_02_id": card["_supportSkillId02"],
        "support_skill_02_level": (
            _required_integer(rank_row, "_supportSkill02Level", label, minimum=1)
            if card["_supportSkillId02"] else None),
        "gekisou_support_skill_id": card["_gekisouSupportSkillId01"],
        "gekisou_support_skill_level": _required_integer(
            rank_row, "_gekisouSupportSkill01Level", label, minimum=1)
            if card["_gekisouSupportSkillId01"] else None,
        "support_rates_10000": values,
        "support_rates_percent_exact": {
            name: f"{value // 100}.{value % 100:02d}" for name, value in values.items()
        },
        "source_row_ids": {"card": card["_id"], "level": level_row["_id"],
                           "limit_break": rank_row["_id"]},
    }


def calculate_selected_card_power(snapshot_dir: Path | str, profile: dict,
                                  member_ids: list[int], snap_ids: list[int]) -> dict:
    """Return selected, owned cards' own stats / rates; verify all source hashes.

    `profile.inventory.members` entries require id, level, training_count and
    awakening_count. Snap entries require id, level and limit_break_count.
    Selection is explicit and preserves order. Skills independent of growth
    (member live / gekisou skills) are not read or assumed by this calculation.
    Absent secondary or gekisou Snap skills have a null derived level.
    """
    owned_members, owned_snaps = _inventory(profile, "members"), _inventory(profile, "snaps")
    member_ids = _selection(member_ids, owned_members, "members")
    snap_ids = _selection(snap_ids, owned_snaps, "snaps")
    manifest, tables = _snapshot(Path(snapshot_dir))
    text = {row["_id"]: row["_japanese"] for row in tables["MasterText"]}
    return {
        "scope": "Own member parameters and base Snap rates only; no complete team simulation",
        "source": {"data_commit": manifest["data_commit"],
                   "source_commit": manifest["source_commit"],
                   "source_snapshot": manifest["source_snapshot"],
                   "verified_file_count": len(REQUIRED_PATHS),
                   "formula_sources": list(FORMULA_SOURCES)},
        "members": [_member(tables, text, identifier, owned_members[identifier]) for identifier in member_ids],
        "snaps": [_snap(tables, text, identifier, owned_snaps[identifier]) for identifier in snap_ids],
    }
